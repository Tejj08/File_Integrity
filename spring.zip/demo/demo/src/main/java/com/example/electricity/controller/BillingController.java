package com.example.electricity.controller;

import org.springframework.web.bind.annotation.*;
import com.example.electricity.model.Billing;
import com.example.electricity.model.Consumer;
import com.example.electricity.repository.ConsumerRepository;
import com.example.electricity.service.BillingService;

import java.util.List;

@RestController
@RequestMapping("/api")
@CrossOrigin
public class BillingController {
    private final BillingService billingService;
    private final ConsumerRepository consumerRepo;

    public BillingController(BillingService billingService, ConsumerRepository consumerRepo) {
        this.billingService = billingService;
        this.consumerRepo = consumerRepo;
    }

    @PostMapping("/consumer")
    public Consumer addConsumer(@RequestBody Consumer consumer) {
        return consumerRepo.save(consumer);
    }

    @GetMapping("/consumer/{id}")
    public Consumer getConsumer(@PathVariable Long id) {
        return consumerRepo.findById(id).orElseThrow();
    }

    @PostMapping("/bill/{consumerId}")
    public Billing generateBill(@PathVariable Long consumerId, @RequestParam int units) {
        return billingService.generateBill(consumerId, units);
    }

    @GetMapping("/bill/{consumerId}")
    public List<Billing> getBills(@PathVariable Long consumerId) {
        return billingService.getBills(consumerId);
    }
}
