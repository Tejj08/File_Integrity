package com.example.electricity.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.electricity.model.Billing;
import com.example.electricity.model.Consumer;
import java.util.List;

public interface BillingRepository extends JpaRepository<Billing, Long> {
    List<Billing> findByConsumer(Consumer consumer);
}
