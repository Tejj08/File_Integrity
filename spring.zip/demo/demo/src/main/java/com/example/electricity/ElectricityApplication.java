package com.example.electricity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ElectricityApplication {
    public static void main(String[] args) {
        SpringApplication.run(ElectricityApplication.class, args);
    }
}
