package com.example.electricity.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.electricity.model.Consumer;

public interface ConsumerRepository extends JpaRepository<Consumer, Long> {
}
