package com.example.electricity.service;

import org.springframework.stereotype.Service;
import com.example.electricity.model.Consumer;
import com.example.electricity.model.Billing;
import com.example.electricity.repository.ConsumerRepository;
import com.example.electricity.repository.BillingRepository;
import java.util.List;

@Service
public class BillingService {
    private final ConsumerRepository consumerRepo;
    private final BillingRepository billingRepo;

    public BillingService(ConsumerRepository consumerRepo, BillingRepository billingRepo) {
        this.consumerRepo = consumerRepo;
        this.billingRepo = billingRepo;
    }

    public Billing generateBill(Long consumerId, int units) {
        Consumer consumer = consumerRepo.findById(consumerId).orElseThrow();
        double amount = calculateBill(units);
        Billing bill = new Billing();
        bill.setConsumer(consumer);
        bill.setUnits(units);
        bill.setAmount(amount);
        return billingRepo.save(bill);
    }

    public List<Billing> getBills(Long consumerId) {
        Consumer consumer = consumerRepo.findById(consumerId).orElseThrow();
        return billingRepo.findByConsumer(consumer);
    }

    private double calculateBill(int units) {
        double amount = 0;
        if (units <= 50)
            amount = units * 3.5;
        else if (units <= 150)
            amount = 50 * 3.5 + (units - 50) * 4;
        else if (units <= 250)
            amount = 50 * 3.5 + 100 * 4 + (units - 150) * 5.2;
        else
            amount = 50 * 3.5 + 100 * 4 + 100 * 5.2 + (units - 250) * 6.5;
        return amount;
    }
}
