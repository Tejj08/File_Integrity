const express = require("express");
const mysql = require("mysql2");
const bodyParser = require("body-parser");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// MySQL connection pool
const pool = mysql.createPool({
  host: "localhost",
  user: "root",
  password: "Va1511@=gmail",
  database: "electricity_db",
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
});

// Electricity bill calculation logic
function calculateBill(units) {
  let amount = 0;
  if (units <= 50) {
    amount = units * 3.5;
  } else if (units <= 150) {
    amount = 50 * 3.5 + (units - 50) * 4.0;
  } else if (units <= 250) {
    amount = 50 * 3.5 + 100 * 4.0 + (units - 150) * 5.2;
  } else {
    amount = 50 * 3.5 + 100 * 4.0 + 100 * 5.2 + (units - 250) * 6.5;
  }
  return amount.toFixed(2);
}

// Create Consumer
app.post("/api/consumers", (req, res) => {
  const { name, address, phone } = req.body;
  pool.query(
    "INSERT INTO Consumer (name, address, phone) VALUES (?, ?, ?)",
    [name, address, phone],
    (err, result) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ consumer_id: result.insertId });
    }
  );
});

// Calculate bill and save billing
app.post("/api/billing", (req, res) => {
  const { consumer_id, units_consumed } = req.body;
  const bill_amount = calculateBill(units_consumed);

  pool.query(
    "INSERT INTO Billing (consumer_id, units_consumed, bill_amount) VALUES (?, ?, ?)",
    [consumer_id, units_consumed, bill_amount],
    (err, result) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ billing_id: result.insertId, bill_amount });
    }
  );
});

// Get all consumers with their latest billing info
app.get("/api/consumers", (req, res) => {
  const query = `
    SELECT c.consumer_id, c.name, c.address, c.phone,
           b.units_consumed, b.bill_amount, b.billing_date
    FROM Consumer c
    LEFT JOIN Billing b ON c.consumer_id = b.consumer_id
    WHERE b.billing_date = (SELECT MAX(b2.billing_date) FROM Billing b2 WHERE b2.consumer_id = c.consumer_id)
    OR b.billing_date IS NULL
  `;

  pool.query(query, (err, results) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(results);
  });
});

// Start server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
